$('input').on('change', function() {
    $('body').toggleClass('blue');
  });
  

  alert('foo');
  window.location.reload(true);
  // Clicking Pic open new  Song list page

  function mouseDown() {
    document.getElementById("myP").innerText = alert("Play song");
  }